package RedisApp.Service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import RedisApp.Domain.UserDetails;
import RedisApp.RedisDatabase.RedisDatabase;


@Service
public class UserService {

	//@Autowired
	RedisDatabase redisDatabase;
	
	HashMap<String, String> map = new HashMap<String, String>();
	
	public HashMap<String, String> createAcc(UserDetails UD)
	{
		map.put("Name", UD.getName());
		map.put("Mobile",UD.getMob());
		map.put("Email", UD.getEmail());
		
		redisDatabase.hmset(UD.getMob(), map);
		
		return map;
	}
	
	
	
	public Map<String, String> getAccDetails(String mob)
	{
		return redisDatabase.hgetAll(mob);
	}
	
}
