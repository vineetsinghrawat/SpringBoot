package RedisApp.RedisDatabase;

import org.springframework.data.redis.connection.RedisConnectionFactory;

import redis.clients.jedis.JedisCommands;

public interface RedisDatabase extends RedisConnectionFactory, JedisCommands {

}
