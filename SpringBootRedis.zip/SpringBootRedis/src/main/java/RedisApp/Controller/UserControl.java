package RedisApp.Controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import RedisApp.Domain.UserDetails;
import RedisApp.Service.UserService;


@RestController
@RequestMapping("/user")
public class UserControl {
	
	@Autowired
	private UserService uServ;
	
	

	@RequestMapping(method = RequestMethod.POST, value = "/newUser")
	public String createAccount(@RequestBody UserDetails ud)
	{
		uServ.createAcc(ud);
		return "Account Created";
		
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/userDetails/{mob}")
	public Map<String, String> getDetails(@PathVariable String mob)
	{
		return uServ.getAccDetails(mob);
		
	}
	

}
