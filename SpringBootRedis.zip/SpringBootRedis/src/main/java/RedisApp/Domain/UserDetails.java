package RedisApp.Domain;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserDetails {

	private String name;
	
	private String email;
	
	@Id
	private String mob;

	public UserDetails()
	{
		super();
	}
	
	public UserDetails(String Name, String Email, String Mob)
	{
		super();
	   
		name = Name;
		
		email = Email;
		
		mob = Mob;
		
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}
	
	
}
